/// Create a list of new candidates
const newCandidates = [
    { name: "Kerrie", skills: ["JavaScript", "Docker", "Ruby"] },
    { name: "Mario", skills: ["Python", "AWS"] },
    { name: "Jacquline", skills: ["JavaScript", "Azure"] },
    { name: "Kathy", skills: ["JavaScript", "Java"] },
    { name: "Anna", skills: ["JavaScript", "AWS"] },
    { name: "Matt", skills: ["PHP", "AWS"] },
    { name: "Matt", skills: ["PHP", ".Net", "Docker"] },
  ];

  /**
   * Remove rows from a given table.
   * @param {*} table the table
   */
  function removeRowsFromTable(table) {
    const rows = table.getElementsByTagName("tr");

    while (rows.length > 1) {
      table.deleteRow(1);
    }
  }

  /**
   * Insert a candidate
   * @param {*} tbody the body
   * @param {*} name the candidate name
   * @param {*} skills the skills the candidate has.
   */
  function insertCandidate(tbody, name, skills) {
    const newRow = tbody.insertRow();
    const nameCell = newRow.insertCell();
    const skillCell = newRow.insertCell();

    const candidateName = document.createTextNode(name);
    const candidateSkills = document.createTextNode(skills.join(', '));

    nameCell.appendChild(candidateName);
    skillCell.appendChild(candidateSkills);
  }

  /**
   * Adds the given candidates to our table.
   * @param {*} table the table
   * @param {*} candidates the candidates to add.
   */
  function addCandidatesToTable(table, candidates) {
    candidates.forEach(candidate => insertCandidate(table, candidate.name, candidate.skills));
  }

  /**
   * loops through our candidates and matches by the given skill, if found adds to filtered list for us to use later.
   * @param {*} candidates 
   * @param {*} skill 
   */
  function filterCandidateBySkill(candidates, skill) {

    var filteredCandidates = [];

    candidates.forEach(candidate => {
        if (candidate.skills.includes(skill)) {
            filteredCandidates.push(candidate);
        }
    });

    return filteredCandidates;
  }

  /**
   * Gets all the skills from our candidates and adds them to a unique list, so we don't get any duplicate skills.
   */
  function getAllPossibleSkills() {
    var possibleSkills = [];

    newCandidates.forEach(candidate => {
        for (const skill of candidate.skills) {
            if (possibleSkills.indexOf(skill) > -1) {
                continue;
            }

            possibleSkills.push(skill);
            console.log(skill);
        }
    })

    return possibleSkills;
  }

  /**
   * Generic function to create multiple tables by different skills, no need for us to duplicate code.
   */
  function createCandidatesTableBySkill() {

    var possibleSkills = getAllPossibleSkills();

    for (const skill of possibleSkills) {
        var tableCaption = document.getElementById("caption");

        if (tableCaption) {
            tableCaption.innerText = skill + " candidates";
        }

        const candidatesTable = document.getElementById("candidates_example");
        candidatesTable.align = 'center';
        const newCandidatesTable = candidatesTable.cloneNode(true);
    
        removeRowsFromTable(newCandidatesTable);
        const newTbody = newCandidatesTable.getElementsByTagName('tbody')[0];
    
        const filteredCandidates = filterCandidateBySkill(newCandidates, skill)
        addCandidatesToTable(newTbody, filteredCandidates)
    
        document.body.appendChild(newCandidatesTable);
    }
  }

  createCandidatesTableBySkill();